#include "v4l2_camera.h"
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <linux/videodev2.h>
#include <iostream>
#include <cstring>

//#define WIDTH 640
//#define HEIGHT 480
#define PIXEL_FORMAT V4L2_PIX_FMT_NV12

V4L2Camera::V4L2Camera(const std::string& device, const int width, const int hight) : fd_(-1), device_(device), width_(width), hight_(hight)
{
}

V4L2Camera::~V4L2Camera()
{
	stop();
	for (int i = 0; i < BUFFER_COUNT; ++i) {
		if (buffers_[i].start)
			munmap(buffers_[i].start, buffers_[i].length);
	}
	if (fd_ >= 0)
		close(fd_);
}

bool V4L2Camera::init()
{

	fd_ = open(device_.c_str(), O_RDWR);
	if (fd_ < 0) {
		perror("Open device");
		return false;
	}

	struct v4l2_format fmt = {};
	fmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
	fmt.fmt.pix_mp.width = width_;
	fmt.fmt.pix_mp.height = hight_;
	fmt.fmt.pix_mp.pixelformat = PIXEL_FORMAT;
	fmt.fmt.pix_mp.field = V4L2_FIELD_NONE;
	fmt.fmt.pix_mp.num_planes = 2;

	if (ioctl(fd_, VIDIOC_S_FMT, &fmt) < 0) {
		perror("Set format");
		return false;
	}

	struct v4l2_requestbuffers req = {};
	req.count = BUFFER_COUNT;
	req.type = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
	req.memory = V4L2_MEMORY_MMAP;

	if (ioctl(fd_, VIDIOC_REQBUFS, &req) < 0) {
		perror("Request buffers");
		return false;
	}

	for (int i = 0; i < BUFFER_COUNT; ++i) {
		struct v4l2_buffer buf = {};
		struct v4l2_plane planes[2] = {};
		buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
		buf.memory = V4L2_MEMORY_MMAP;
		buf.index = i;
		buf.length = 2;
		buf.m.planes = planes;

		if (ioctl(fd_, VIDIOC_QUERYBUF, &buf) < 0) {
			perror("Query buffer");
			return false;
		}

		size_t total_len = buf.m.planes[0].length + buf.m.planes[1].length;
		buffers_[i].length = total_len;
		buffers_[i].start = mmap(NULL, total_len, PROT_READ | PROT_WRITE, MAP_SHARED, fd_, buf.m.planes[0].m.mem_offset);
		if (buffers_[i].start == MAP_FAILED) {
			perror("mmap");
			return false;
		}

		if (ioctl(fd_, VIDIOC_QBUF, &buf) < 0) {
			perror("Initial queue buffer");
			return false;
		}
	}

	return true;
}

bool V4L2Camera::start()
{
	enum v4l2_buf_type type = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
	if (ioctl(fd_, VIDIOC_STREAMON, &type) < 0) {
		perror("Stream on");
		return false;
	}
	return true;
}

bool V4L2Camera::stop()
{
	enum v4l2_buf_type type = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
	if (ioctl(fd_, VIDIOC_STREAMOFF, &type) < 0) {
		perror("Stream off");
		return false;
	}
	return true;
}

bool V4L2Camera::getFrame(cv::Mat& frame)
{
	struct v4l2_buffer buf = {};
	struct v4l2_plane planes[2] = {};
	buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
	buf.memory = V4L2_MEMORY_MMAP;
	buf.length = 2;
	buf.m.planes = planes;

	if (ioctl(fd_, VIDIOC_DQBUF, &buf) < 0) {
		perror("Dequeue buffer");
		return false;
	}

	unsigned char* y_plane = static_cast<unsigned char*>(buffers_[buf.index].start);
	cv::Mat nv12(hight_ * 3 / 2, width_, CV_8UC1, y_plane);
	cv::cvtColor(nv12, frame, cv::COLOR_YUV2BGR_NV12);

	if (ioctl(fd_, VIDIOC_QBUF, &buf) < 0) {
		perror("Requeue buffer");
		return false;
	}

	return true;
}

