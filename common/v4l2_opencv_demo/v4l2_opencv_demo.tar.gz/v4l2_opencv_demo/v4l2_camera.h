#pragma once

#include <opencv2/opencv.hpp>

class V4L2Camera
{
public:
	V4L2Camera(const std::string& device, const int width, const int hight);
	~V4L2Camera();

	bool init();
	bool start();
	bool stop();
	bool getFrame(cv::Mat& frame);

private:
	struct V4L2Buffer {
		void* start;
		size_t length;
	};

	static const int BUFFER_COUNT = 4;
	int fd_;
	std::string device_;
	const int width_;
	const int hight_;
	V4L2Buffer buffers_[BUFFER_COUNT];
};

